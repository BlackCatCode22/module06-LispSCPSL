// TD 10/03/2024
// zooVersion01.java

package tyler.zoo.com;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.stream.StreamSupport;

public class App {



    public static void Main(String[] args) {

        System.out.println("\nWelcome to my Zoo Program!");

        String filePath = "C:\\Users\\BE218\\IdeaProjects\\ZooPopulation\\arrivingAnimals.txt";


        // Make sure to redirect the animal.txt file directory in case of error.
        try (BufferedReader bufferedReader = new BufferedReader(new FileReader("C:\\Users\\BE218\\IdeaProjects\\ZooPopulation\\arrivingAnimals.txt"))) {
            String line;
            // Read each line until the end of the file
            while ((line = bufferedReader.readLine()) != null) {
                System.out.println(line);
            }
        } catch (IOException e) {
            // Handle the exception
            System.err.println("Error reading file: " + e.getMessage());
        }
        System.out.println("\n\n");


        AnimalNameListsWrapper animalLists = Utilities.createAnimalNameLists("C:\\Users\\BE218\\IdeaProjects\\ZooPopulation\\animalNames.txt");

        String aniSex;
        String aniSpecies;





        // parse the string
        String strStarting = "12 year old male hyena, born in fall, brown color, 150 pounds, from Friguia Park, Tunisia";

        String[] arrayOfStrPartsOnComma = strStarting.split(", ");

        int elementNum = 0;
        for (String thePart : arrayOfStrPartsOnComma) {
            System.out.println("Element " + elementNum + " of the string is: " + thePart);
            elementNum++;
        }

        String aniColor;
        String aniWeight;
        String aniOrigin01;
        String aniOrigin02;
        String aniAge;

        aniColor = arrayOfStrPartsOnComma[2];
        aniWeight = arrayOfStrPartsOnComma[3];
        aniOrigin01 = arrayOfStrPartsOnComma[4];
        aniOrigin02 = arrayOfStrPartsOnComma[5];



        System.out.println("\n");

        String[] arrayOfStrPartsOnSpace = arrayOfStrPartsOnComma[0].split(" ");
        elementNum = 0;
        for (String thePart : arrayOfStrPartsOnSpace) {
            System.out.println("Element " + elementNum + " of the string is: " + thePart);
            elementNum++;
        }

        // Get animal's sex and species and age
        aniAge = arrayOfStrPartsOnSpace[0];
        // make this an int.
        int intAniAge = Integer.parseInt(aniAge);
        aniSex = arrayOfStrPartsOnSpace[3];
        aniSpecies = arrayOfStrPartsOnSpace[4];
        System.out.println("\nThe animal's sex is " + aniSex);
        System.out.println("\nThe species is " + aniSpecies);
        System.out.println("\nThe color is " + aniColor);
        System.out.println("\nThe weight is " + aniWeight);
        System.out.println("\nOrigin01 is " + aniOrigin01);
        System.out.println("\nOrigin02 is " + aniOrigin02);


        String ageInYears = arrayOfStrPartsOnSpace[0];
        System.out.println("\nThe age in years of the animal is: " + ageInYears);


        System.out.println("\n");

        String[] arrayOfStrPartsOnSpace02 = arrayOfStrPartsOnComma[1].split(" ");
        elementNum = 0;
        for (String thePart : arrayOfStrPartsOnSpace02) {
            System.out.println("Element " + elementNum + " of the string is: " + thePart);
            elementNum++;
        }

        String animalBirthSeason = arrayOfStrPartsOnSpace02[2];
        System.out.println("\nThe season of birth of the animal is: " + animalBirthSeason);


        String animalBirthdate = "";
        int todaysYear = Integer.parseInt(strTodaysYear);
        int animalBirthYear = todaysYear - Integer.parseInt(ageInYears);


        if (animalBirthSeason.contains("spring")) {
            animalBirthdate = animalBirthYear + "-03-21";
        }

        if (animalBirthSeason.contains("fall")) {
            animalBirthdate = animalBirthYear + "-09-21";
        }

        if (animalBirthSeason.contains("winter")) {
            animalBirthdate = animalBirthYear + "-12-21";
        }
        if (animalBirthSeason.contains("summer")) {
            animalBirthdate = animalBirthYear + "-06-21";
        }


        System.out.println("\nanimalBirthdate = " + animalBirthdate);



        // Create the right animal object for this arriving animal.
        if (aniSpecies.equals("hyena")) {
            System.out.println("\n The animal is a Hyena");
            // Create a hyena object and attach to the hyena ArrayList;
            HyenaOct3 Hyena = new HyenaOct3(aniSex, intAniAge, 99, "to be named", "animalID",
                    "animalBirthDate", aniColor, aniOrigin01 + aniOrigin02);
        }

        System.out.println("The new hyena's color is: ");

        // Unit test
        tyler.zoo.com.AnimalOct3 myNewAnimal = new tyler.zoo.com.AnimalOct3("Male", 4, 70, "Zig",
                "Hy01", "2020-3-21", "Brown Spots", "from San Diego Zoo");


        // Prove it
        System.out.println("\nThis is the new animal!\n");
        System.out.println("ID is: " + myNewAnimal.getAnimalID() + " and... name is: " + myNewAnimal.getAnimalName() + "\n");

        System.out.println("Animal birthdate is: " + Utilities.calcAnimalBirthDate(Integer.parseInt(ageInYears), animalBirthSeason));




    }
}